#!/usr/bin/env bash
# Builds libzcore.so for arm64-v8a (OnePlus 13R) and generates Kotlin bindings.
# Requires: rustup, cargo-ndk (cargo install cargo-ndk), Android NDK r28+ (ANDROID_NDK_HOME set).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/rust/zcore"

rustup target add aarch64-linux-android
cargo ndk -t arm64-v8a -o "$ROOT/app/src/main/jniLibs" build --release

cargo run --features bindgen --bin uniffi-bindgen -- generate \
  --library target/aarch64-linux-android/release/libzcore.so \
  --language kotlin \
  --out-dir "$ROOT/app/src/main/java" \
  --no-format

echo "Done. Open the project root in Android Studio and run on the device."
