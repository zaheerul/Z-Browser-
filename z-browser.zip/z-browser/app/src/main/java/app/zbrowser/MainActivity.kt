package app.zbrowser

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.window.OnBackInvokedDispatcher
import uniffi.zcore.blockedCount
import uniffi.zcore.loadFilterList
import uniffi.zcore.resolveInput
import uniffi.zcore.shouldBlock
import uniffi.zcore.upgradeToHttps
import java.io.ByteArrayInputStream
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar

    @Volatile private var topUrl = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                WindowInsets.CONSUMED
            }
        }

        urlBar = EditText(this).apply {
            hint = "Search or enter address"
            setSingleLine()
            inputType = EditorInfo.TYPE_CLASS_TEXT or EditorInfo.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setOnEditorActionListener { v, actionId, event ->
                val enter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
                if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                    go(v.text.toString())
                    true
                } else false
            }
        }

        val reload = TextView(this).apply {
            text = "⟳"
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { web.reload() }
            setOnLongClickListener {
                Toast.makeText(context, "Blocked ${blockedCount()} requests", Toast.LENGTH_SHORT).show()
                true
            }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), 0, dp(4))
            addView(urlBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(reload, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = android.view.View.GONE
        }

        web = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                safeBrowsingEnabled = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
            }
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            webViewClient = ZClient()
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) android.view.View.VISIBLE else android.view.View.GONE
                }
            }
        }

        root.addView(bar)
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        window.insetsController?.setSystemBarsAppearance(
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
        )

        // targetSdk 36: legacy onBackPressed() is no longer called, use the predictive-back dispatcher.
        onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) {
            if (web.canGoBack()) web.goBack() else finish()
        }

        // Load the full filter list off the main thread (also warms up the native library).
        thread(name = "zcore-init") {
            runCatching {
                val text = assets.open("filters.txt").bufferedReader().use { it.readText() }
                loadFilterList(text)
            }
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(intent?.data?.toString() ?: HOME)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.let { web.loadUrl(it.toString()) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private fun go(text: String) {
        web.loadUrl(resolveInput(text, SEARCH))
        urlBar.clearFocus()
        web.requestFocus()
        window.insetsController?.hide(WindowInsets.Type.ime())
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private inner class ZClient : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            if (request.isForMainFrame) return null
            val url = request.url.toString()
            if (!url.startsWith("http")) return null
            return if (shouldBlock(url, topUrl, guessType(url, request))) {
                WebResourceResponse("text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            } else null
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url.toString()
            return when (request.url.scheme) {
                "https" -> false
                "http" -> {
                    val upgraded = upgradeToHttps(url)
                    if (upgraded != url) { view.loadUrl(upgraded); true } else false
                }
                else -> true // ignore javascript:, intent:, file:, custom schemes
            }
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            topUrl = url
            if (!urlBar.hasFocus()) urlBar.setText(url)
        }

        override fun onPageFinished(view: WebView, url: String) {
            topUrl = url
            if (!urlBar.hasFocus()) urlBar.setText(url)
        }
    }

    private fun guessType(url: String, request: WebResourceRequest): String {
        val path = request.url.path?.lowercase().orEmpty()
        return when {
            path.endsWith(".js") || path.endsWith(".mjs") -> "script"
            path.endsWith(".css") -> "stylesheet"
            path.endsWith(".png") || path.endsWith(".jpg") || path.endsWith(".jpeg") ||
                path.endsWith(".gif") || path.endsWith(".webp") || path.endsWith(".svg") ||
                path.endsWith(".avif") -> "image"
            path.endsWith(".woff") || path.endsWith(".woff2") || path.endsWith(".ttf") -> "font"
            path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".m3u8") -> "media"
            else -> {
                val accept = request.requestHeaders["Accept"].orEmpty()
                when {
                    accept.contains("text/css") -> "stylesheet"
                    accept.startsWith("image/") -> "image"
                    accept.contains("text/html") -> "subdocument"
                    request.requestHeaders["X-Requested-With"] == "XMLHttpRequest" -> "xmlhttprequest"
                    else -> "other"
                }
            }
        }
    }

    private companion object {
        const val HOME = "https://duckduckgo.com"
        const val SEARCH = "https://duckduckgo.com/?q={}"
    }
}
