//! Z-Browser core. Exposed to Kotlin through UniFFI (proc-macro mode).

use std::net::IpAddr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{OnceLock, RwLock};

use adblock::Engine;
use adblock::lists::{FilterSet, ParseOptions};
use adblock::request::Request;
use url::{Host, Url};

uniffi::setup_scaffolding!();

const BUILTIN_RULES: &str = include_str!("../assets/builtin_filters.txt");
const DEFAULT_SEARCH: &str = "https://duckduckgo.com/?q={}";

static ENGINE: OnceLock<RwLock<Engine>> = OnceLock::new();
static BLOCKED: AtomicU64 = AtomicU64::new(0);

fn build_engine(extra: &str) -> (Engine, u32) {
    let rules: Vec<String> = BUILTIN_RULES
        .lines()
        .chain(extra.lines())
        .map(str::trim)
        .filter(|l| !l.is_empty() && !l.starts_with('!') && !l.starts_with('['))
        .map(str::to_owned)
        .collect();
    let count = rules.len() as u32;
    let mut set = FilterSet::new(false);
    let _ = set.add_filters(&rules, ParseOptions::default());
    (Engine::from_filter_set(set, true), count)
}

fn engine() -> &'static RwLock<Engine> {
    ENGINE.get_or_init(|| RwLock::new(build_engine("").0))
}

/// Replace the active filter set with built-in rules + `list` (e.g. EasyList text).
/// Returns the number of rules loaded.
#[uniffi::export]
pub fn load_filter_list(list: String) -> u32 {
    let (new_engine, count) = build_engine(&list);
    match engine().write() {
        Ok(mut guard) => *guard = new_engine,
        Err(poisoned) => *poisoned.into_inner() = new_engine,
    }
    count
}

/// True if a sub-resource request should be blocked. Never blocks on internal errors.
#[uniffi::export]
pub fn should_block(url: String, source_url: String, resource_type: String) -> bool {
    let Ok(request) = Request::new(&url, &source_url, &resource_type) else {
        return false;
    };
    let Ok(guard) = engine().read() else {
        return false;
    };
    let blocked = guard.check_network_request(&request).matched;
    if blocked {
        BLOCKED.fetch_add(1, Ordering::Relaxed);
    }
    blocked
}

#[uniffi::export]
pub fn blocked_count() -> u64 {
    BLOCKED.load(Ordering::Relaxed)
}

/// Turn whatever the user typed into a loadable URL (or a search URL).
/// `search_template` must be an https URL containing `{}`; otherwise DuckDuckGo is used.
#[uniffi::export]
pub fn resolve_input(input: String, search_template: String) -> String {
    let t = input.trim();
    if t.is_empty() {
        return "about:blank".to_owned();
    }

    let lower = t.to_ascii_lowercase();
    if lower.starts_with("http://") || lower.starts_with("https://") {
        if let Ok(u) = Url::parse(t) {
            if u.host().is_some() {
                return u.to_string();
            }
        }
    }

    if !t.chars().any(char::is_whitespace) {
        if let Ok(mut u) = Url::parse(&format!("https://{t}")) {
            if u.username().is_empty() && looks_navigable(&u) {
                if is_local(&u) {
                    let _ = u.set_scheme("http");
                }
                return u.to_string();
            }
        }
    }

    let template = if search_template.starts_with("https://") && search_template.contains("{}") {
        search_template.as_str()
    } else {
        DEFAULT_SEARCH
    };
    let q: String = url::form_urlencoded::byte_serialize(t.as_bytes()).collect();
    template.replacen("{}", &q, 1)
}

fn looks_navigable(u: &Url) -> bool {
    match u.host() {
        Some(Host::Domain(d)) => {
            d.eq_ignore_ascii_case("localhost")
                || d.rsplit_once('.').is_some_and(|(_, tld)| {
                    tld.starts_with("xn--")
                        || (tld.len() >= 2 && tld.chars().all(|c| c.is_ascii_alphabetic()))
                })
        }
        Some(Host::Ipv4(_)) | Some(Host::Ipv6(_)) => true,
        None => false,
    }
}

fn is_local(u: &Url) -> bool {
    match u.host() {
        Some(Host::Domain(d)) => d.eq_ignore_ascii_case("localhost"),
        Some(Host::Ipv4(ip)) => IpAddr::V4(ip).is_loopback() || ip.is_private(),
        Some(Host::Ipv6(ip)) => ip.is_loopback(),
        None => false,
    }
}

/// Upgrade http:// to https:// for public hostnames on default ports.
#[uniffi::export]
pub fn upgrade_to_https(url: String) -> String {
    let Ok(mut u) = Url::parse(&url) else {
        return url;
    };
    if u.scheme() != "http" || u.port().is_some() {
        return url;
    }
    let domain = match u.host() {
        Some(Host::Domain(d)) => Some(d.to_ascii_lowercase()),
        _ => None,
    };
    if let Some(d) = domain {
        let private = d == "localhost"
            || d.ends_with(".local")
            || d.ends_with(".internal")
            || d.ends_with(".lan")
            || !d.contains('.');
        if !private && u.set_scheme("https").is_ok() {
            return u.to_string();
        }
    }
    url
}

#[uniffi::export]
pub fn core_version() -> String {
    env!("CARGO_PKG_VERSION").to_owned()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn r(s: &str) -> String {
        resolve_input(s.to_owned(), String::new())
    }

    #[test]
    fn urls_and_hosts() {
        assert_eq!(r("https://example.com/a"), "https://example.com/a");
        assert_eq!(r("example.com"), "https://example.com/");
        assert_eq!(r("localhost:3000"), "http://localhost:3000/");
    }

    #[test]
    fn searches() {
        assert_eq!(r("rust lang"), "https://duckduckgo.com/?q=rust+lang");
        assert_eq!(r("javascript:alert(1)"), "https://duckduckgo.com/?q=javascript%3Aalert%281%29");
        assert_eq!(r(""), "about:blank");
    }

    #[test]
    fn https_upgrade() {
        assert_eq!(upgrade_to_https("http://example.com/x".into()), "https://example.com/x");
        assert_eq!(upgrade_to_https("http://localhost/x".into()), "http://localhost/x");
        assert_eq!(upgrade_to_https("http://example.com:8080/".into()), "http://example.com:8080/");
    }

    #[test]
    fn blocking() {
        assert!(should_block(
            "https://ad.doubleclick.net/x.js".into(),
            "https://news.example.com/".into(),
            "script".into()
        ));
        assert!(!should_block(
            "https://news.example.com/app.js".into(),
            "https://news.example.com/".into(),
            "script".into()
        ));
    }
}
